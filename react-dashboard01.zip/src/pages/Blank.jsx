// import React, { useState, useRef } from 'react';
// import useFormState from '@arco-design/web-react/es/Form/hooks/useState';
// import { useState } from 'react';
// import { Document, Page } from 'react-pdf';
const Blank = () => {
    return (
        <div>
            This is a blank page
        </div>
    )
};


export default Blank

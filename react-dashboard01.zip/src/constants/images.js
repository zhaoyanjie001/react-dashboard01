const images = {
    logo: require('../assets/images/logo.svg').default,
    avt: require('../assets/images/avt.jpg')
}

export default images
package org.yjb.business.login.service.impl;

import org.yjb.business.login.service.IService;

public class  BaseService<T> implements IService<T> {

}

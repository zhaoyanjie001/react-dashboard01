package org.yjb.business.login.service;

import org.springframework.stereotype.Service;

/**
 * 通用接口
 */
@Service
public interface IService<T> {

}

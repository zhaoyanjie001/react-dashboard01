package org.yjb.business.edi.service.impl;

import org.yjb.business.edi.service.IService;

public class  BaseService<T> implements IService<T> {

}

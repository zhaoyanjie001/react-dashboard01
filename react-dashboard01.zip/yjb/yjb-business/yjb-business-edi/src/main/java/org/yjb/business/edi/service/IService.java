package org.yjb.business.edi.service;

import org.springframework.stereotype.Service;

/**
 * 通用接口
 */
@Service
public interface IService<T> {

}

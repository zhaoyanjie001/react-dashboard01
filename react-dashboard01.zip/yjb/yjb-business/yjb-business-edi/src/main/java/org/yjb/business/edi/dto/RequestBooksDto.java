package org.yjb.business.edi.dto;

public class RequestBooksDto {
	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}

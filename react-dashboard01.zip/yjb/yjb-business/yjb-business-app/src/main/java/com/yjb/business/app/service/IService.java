package com.yjb.business.app.service;

import org.springframework.stereotype.Service;

/**
 * 通用接口
 */
@Service
public interface IService<T> {

}
